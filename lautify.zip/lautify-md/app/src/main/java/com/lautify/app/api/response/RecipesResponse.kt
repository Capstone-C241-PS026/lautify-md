package com.lautify.app.api.response

import com.google.gson.annotations.SerializedName

data class RecipesResponse(

	@field:SerializedName("RecipesResponse")
	val recipesResponse: List<RecipesResponseItem>
)

data class RecipesResponseItem(

	@field:SerializedName("readyInMinutes")
	val readyInMinutes: Int,

	@field:SerializedName("image")
	val image: String,

	@field:SerializedName("types")
	val types: List<String>,

	@field:SerializedName("title")
	val title: String,

	@field:SerializedName("rid")
	val rid: Int
)
