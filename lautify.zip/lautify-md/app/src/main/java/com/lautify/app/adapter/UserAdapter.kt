package com.lautify.app.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.view.menu.MenuView.ItemView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.lautify.app.api.response.RecipesResponseItem
import com.lautify.app.databinding.FragmentRecipeBinding
import com.lautify.app.databinding.RecipeItemBinding

class UserAdapter(
    private val  listRecipe : ArrayList<RecipesResponseItem>
):RecyclerView.Adapter<UserAdapter.UserViewHolder>(){

    inner class UserViewHolder(itemView: RecipeItemBinding):RecyclerView.ViewHolder(itemView.root){
        private val binding = itemView
        fun bind(recipesResponseItem: RecipesResponseItem){
            with(binding){
                Glide.with(itemView).load(recipesResponseItem.image).into(cardImage)
                title.text = recipesResponseItem.title
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        return UserViewHolder(RecipeItemBinding.inflate(LayoutInflater.from(parent.context),
            parent, false))
    }

    override fun getItemCount(): Int = listRecipe.size

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        holder.bind(listRecipe[position])
    }
}
