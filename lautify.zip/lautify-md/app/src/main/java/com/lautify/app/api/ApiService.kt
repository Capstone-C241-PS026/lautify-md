package com.lautify.app.api

import com.lautify.app.api.response.RecipesResponse
import com.lautify.app.api.response.RecipesResponseItem
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("recipes") // Replace with your actual endpoint
    fun getRecipes(): Call<RecipesResponse>
}
