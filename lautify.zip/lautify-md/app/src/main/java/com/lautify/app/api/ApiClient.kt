package com.lautify.app.api

import com.lautify.app.api.response.RecipesResponseItem
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create
import retrofit2.http.GET

object ApiClient {

    private const val  BASE_URL = "https://6661311163e6a0189fe8cfbc.mockapi.io/api/v1/recipes"
    val instances:ApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        retrofit.create(ApiService::class.java)
    }
}


