package com.lautify.app.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.lautify.app.adapter.UserAdapter
import com.lautify.app.api.ApiClient
import com.lautify.app.api.response.RecipesResponse
import com.lautify.app.api.response.RecipesResponseItem
import com.lautify.app.databinding.FragmentRecipeBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RecipeFragment : Fragment() {

    private var _binding: FragmentRecipeBinding? = null
    private val binding get() = _binding!!
    private val list = ArrayList<RecipesResponseItem>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentRecipeBinding.inflate(inflater, container, false) //
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvData.setHasFixedSize(true)
        binding.rvData.layoutManager = LinearLayoutManager(context)

        ApiClient.instances.getRecipes().enqueue(object : Callback<RecipesResponse> {
            override fun onResponse(
                call: Call<RecipesResponse>,
                response: Response<RecipesResponse>
            ) {
                val responseCode = response.code()
                response.body()?.let { list.addAll(it.recipesResponse) }
                val adapter = UserAdapter(list)
                binding.rvData.adapter = adapter
            }

            override fun onFailure(call: Call<RecipesResponse>, t: Throwable) {
                TODO("Not yet implemented")
            }
        }
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding=null
    }
}
